<?php 

/**
 * Immiration enqueue style and script.
 */


function immiration_theme_scripts() {

	//Load All style
    wp_enqueue_style( 'pagestyle', get_stylesheet_uri());
    wp_enqueue_style( 'bootstrap', get_template_directory_uri(). '/css/bootstrap.css', array());
    wp_enqueue_style( 'responsive', get_template_directory_uri(). '/css/responsive.css', array());
    wp_enqueue_style( 'animations', get_template_directory_uri(). '/css/animations.css', array());
    wp_enqueue_style( 'slides-css', get_template_directory_uri(). '/css/slides.css', array());
    wp_enqueue_style( 'custom', get_template_directory_uri(). '/css/custom.css', array());
    wp_enqueue_style( 'flexisel',get_template_directory_uri(). '/css/flexisel.css', array());
    wp_enqueue_style( 'bootstrap-select',get_template_directory_uri(). '/css/bootstrap-select.css', array());
    wp_enqueue_style( 'fobtaw',get_template_directory_uri(). '/css/font-awesome.min.css', array());


    //Load All Script
    wp_deregister_script('jquery');
    wp_enqueue_script( 'jquery', get_template_directory_uri() . '/js/jquery.js', array(),'1.0.0', true );
    wp_enqueue_script( 'plugins', get_template_directory_uri() . '/js/plugins.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'slides', get_template_directory_uri() . '/js/slides.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'bootstrap-min', get_template_directory_uri() . '/js/bootstrap.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'jquery-flexisel', get_template_directory_uri() . '/js/jquery.flexisel.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'bootstrap-select', get_template_directory_uri() . '/js/bootstrap-select.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'css3-animate-it', get_template_directory_uri() . '/js/css3-animate-it.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'scripts', get_template_directory_uri() . '/js/scripts.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'custom', get_template_directory_uri() . '/js/custom.js', array('jquery'), '1.0.0', true );


    
}
add_action( 'wp_enqueue_scripts', 'immiration_theme_scripts' );


/* Register Menu call for new theme*/

register_nav_menus(array(
    'primary' => __('Primary Menu', 'My_First_WordPress_Theme'),
    'secondary' => __('Secondary Menu', 'My_First_WordPress_Theme'),
    'footer' => __('Footer Menu', 'My_First_WordPress_Theme')
));

//wp_nav_menu( array( 'theme_location' => 'primary', 'container_class' => 'my_css_class' ) );


register_sidebar( array(
'name' => 'Footer Left',
'id' => 'footer-left',
'description' => 'Appears in the footer left area',
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => '</aside>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );
register_sidebar( array(
'name' => 'Footer Center',
'id' => 'footer-center',
'description' => 'Appears in the footer center area',
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => '</aside>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );
register_sidebar( array(
'name' => 'Footer Right',
'id' => 'footer-right',
'description' => 'Appears in the footer right bottom area',
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => '</aside>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );
register_sidebar( array(
'name' => 'Footer Bottom',
'id' => 'footer-bottom',
'description' => 'Appears in the footer bottom area',
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => '</aside>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );
register_sidebar( array(
'name' => 'Header Social Icon',
'id' => 'header-social-icon',
'description' => 'Appears in the footer bottom area',
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => '</aside>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );

/* 
**
*Create Custom Post Type Name Services
*/


$labels_service = array(
        'name'               => _x( 'Services', 'post type general name', 'service' ),
        'singular_name'      => _x( 'Service', 'post type singular name', 'service' ),
        'menu_name'          => _x( 'Services', 'admin menu', 'service' ),
        'name_admin_bar'     => _x( 'Service', 'add new on admin bar', 'service' ),
        'add_new'            => _x( 'Add New', 'Service', 'service' ),
        'add_new_item'       => __( 'Add New Service', 'service' ),
        'new_item'           => __( 'New Service', 'service' ),
        'edit_item'          => __( 'Edit Service', 'service' ),
        'view_item'          => __( 'View Service', 'service' ),
        'all_items'          => __( 'All Services', 'service' ),
        'search_items'       => __( 'Search Services', 'service' ),
        'parent_item_colon'  => __( 'Parent Service:', 'service' ),
        'not_found'          => __( 'No service found.', 'service' ),
        'not_found_in_trash' => __( 'No service found in Trash.', 'service' )
    );

    $service = array(
        'labels'             => $labels_service,
        'description'        => __( 'Description.', 'service' ),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'service' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
    );

    register_post_type( 'service', $service );

    /* 
**
*Create Custom Post Type Name Team
*/


$labelsteam = array(
        'name'               => _x( 'Team', 'post type general name', 'team' ),
        'singular_name'      => _x( 'Team', 'post type singular name', 'team' ),
        'menu_name'          => _x( 'Team', 'admin menu', 'service' ),
        'name_admin_bar'     => _x( 'Team', 'add new on admin bar', 'team' ),
        'add_new'            => _x( 'Add New', 'Team', 'team' ),
        'add_new_item'       => __( 'Add New Team', 'team' ),
        'new_item'           => __( 'New Team', 'team' ),
        'edit_item'          => __( 'Edit Team', 'team' ),
        'view_item'          => __( 'View Team', 'team' ),
        'all_items'          => __( 'All Team', 'team' ),
        'search_items'       => __( 'Search Team', 'team' ),
        'parent_item_colon'  => __( 'Parent Team:', 'team' ),
        'not_found'          => __( 'No team found.', 'team' ),
        'not_found_in_trash' => __( 'No team found in Trash.', 'team' )
    );

    $team = array(
        'labels'             => $labelsteam,
        'description'        => __( 'Description.', 'team' ),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'team' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
    );

    register_post_type( 'team', $team );
    
    add_theme_support( 'post-thumbnails' );


    /*
    *
    * Close PLugin update for custom code
    * @PluginName: Testimonial Basics
    */

    add_filter('site_transient_update_plugins', 'remove_update_notification');
    function remove_update_notification($value) {
         unset($value->response["testimonial-basics/testimonial-basics.php"]);
         return $value;
    } 
   

   /* This function help to show recent post in CPT*/

    function recent_post_cat_based( $atts ) {

        //[recent-post-cat shortcodehelper=migrate postcount= 2]
        //[recent-post-cat shortcodehelper=study postcount= 4]     
        $args = array(
        'post_type' => 'post',
        'post_status' =>'publish',
        'posts_per_page'=> $atts['postcount'],
        'order'=>'DESC',
        'orderby'=>'ID',
        'tax_query' => array(
            array(
            'taxonomy' => 'category',
            'field' => 'slug',
            'terms' => $atts['shortcodehelper']
             )
          )
        );
        $the_query = new WP_Query( $args );
        $posts = $the_query->posts;      
        $html = '<div class="shortcode-helper"><div class="post-services">';
        foreach($posts as $postKey => $postVal){
        $url = site_url().'/'.$postVal->post_name;
            $html .= '<div class="post-shortcode"id="post-'.$postKey.'">';
            if(get_post_thumbnail_id($postVal->ID) !== ''){
                $html .= '<img src='.get_the_post_thumbnail_url($postVal->ID).' width="274" height="125" border="0">';
            }
            $html .= '<h3><a href='.$url.'>'.$postVal->post_title.'</a></h3>';
            $html .= '<p>'.wp_trim_words( $postVal->post_content, 50, NULL ).'</p><a href='.$url.' class="common_anchor">Read More</a></div>';
        }
        
        $html .= '</div></div>';
        ob_start();
        echo $html;
        $output = ob_get_clean();
        return $output;

    }
    add_shortcode( 'recent-post-cat', 'recent_post_cat_based' ); 