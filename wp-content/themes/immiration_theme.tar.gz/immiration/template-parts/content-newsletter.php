<section class="slide whiteSlide newsletter_section animatedParent" id="newsletter">
  <div class="content" >
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center common_tittle">
          <h2 class="text-uppercase">NEWSLETTER</h2>
          <span></span> </div>
        <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-12 text-center contact_desc_column">
         <?php echo do_shortcode('[mc4wp_form id="65"]'); ?>
        </div>
      </div>
    </div>
  </div>
</section>