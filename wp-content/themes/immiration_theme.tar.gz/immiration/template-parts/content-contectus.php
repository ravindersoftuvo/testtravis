<section class="slide whiteSlide contact_us_section animatedParent" id="contact_us">
  <div class="content" >
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center common_tittle">
          <h2 class="text-uppercase animated fadeInUpShort">Contact Us </h2>
          <span></span> </div>
        <div class="col-md-6 col-sm-6 col-xs-12 text-center contact_desc_column animated fadeInUpShort">
          <div class="contact_desc_wrapper">
            <div class="contact_desc_inner"> <img src="<?php echo get_field('contact_us_left_imgurl'); ?>" alt="Image"/>
              <p><?php echo get_field('contact_us_left_address'); ?></p>
              <p>
                <label>Phone:</label><?php echo get_field('contact_us_left_phone'); ?></p>
              <p>
                <label>Email:</label>
                <a href="mailto:<?php echo get_field('contact_us_left_email'); ?>"><?php echo get_field('contact_us_left_email'); ?></a></p>
              <p>
                <label>Web:</label>
                <a href="<?php echo get_field('contact_us_left_web'); ?>" target="_blank"><?php echo get_field('contact_us_left_web'); ?></a></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-sm-6 col-xs-12 text-center contact_desc_column animated fadeInUpShort">
          <div class="contact_desc_wrapper">
            <div class="contact_desc_inner"> <img src="<?php echo get_field('contact_us_right_imgurl'); ?>" alt="Image"/>
              <p><?php echo get_field('contact_us_right_address'); ?></p>
              <p>
                <label>Phone:</label><?php echo get_field('contact_us_right_phone'); ?></p>
              <p>
                <label>Email:</label>
                <a href="mailto:<?php echo get_field('contact_us_right_email'); ?>"><?php echo get_field('contact_us_right_email'); ?></a></p>
              <p>
                <label>Web:</label>
                <a href="<?php echo get_field('contact_us_right_web'); ?>" target="_blank"><?php echo get_field('contact_us_right_web'); ?></a></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>