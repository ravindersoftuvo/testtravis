<section class="slide video_section animatedParent" id="video">
	<div class="col-md-12 text-center common_tittle">
  <h2 class="text-uppercase">Videos</h2>
  <span></span> </div>
 <?php echo do_shortcode('[wonderplugin_slider id=1]'); ?>
</section>