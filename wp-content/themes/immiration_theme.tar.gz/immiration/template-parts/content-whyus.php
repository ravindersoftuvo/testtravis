<section class="slide whiteSlide why_us_section animatedParent" id="whyus">
  <div class="content" >
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center common_tittle">
          <h2 class="text-uppercase animated fadeInUpShort"><?php echo get_field( "why_us_title" ); ?></h2>
          <span></span> </div>
        <div class="col-md-12 text-center why_us_section_text animated fadeInUpShort">
         <?php echo get_field( "why_us_content" ); ?>
        </div>
      </div>
    </div>
  </div>
</section>