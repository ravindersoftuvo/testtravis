
<section class="slide fade testimonials_section animatedParent" id="testimonials">
  <div class="content" >
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center common_tittle">
          <h2 class="text-uppercase animated fadeInUpShort">Testimonials</h2>
          <span></span> </div>
        <div class="clearfix"></div>
        <?php echo do_shortcode('[katb_testimonial group="all" number="all" by="random" id="" rotate="no" layout="1" schema="default"]');?>
      </div>
    </div>
  </div>
</section>
